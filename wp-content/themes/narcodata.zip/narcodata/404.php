<?php get_header(); ?>
404
<?php get_footer(); ?>