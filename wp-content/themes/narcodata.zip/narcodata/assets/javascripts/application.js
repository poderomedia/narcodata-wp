$(document).ready(function(){

  $('.dropdown').on('show.bs.dropdown', function(){
    $('body').addClass("dropdown-open");
  });


  $('.dropdown').on('hide.bs.dropdown', function(){
    $('body').removeClass("dropdown-open");
  });

});