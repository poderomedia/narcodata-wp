<!DOCTYPE html>
<html xmlns:fb="http://ogp.me/ns/fb#">
	<head>
		<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
		<link rel="shortcut icon" href="<?php bloginfo('template_url'); ?>/favicon.ico" />
		<title><?php wp_title('&laquo;', true, 'right'); ?> <?php bloginfo('name'); ?></title>

		<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/assets/stylesheets/application.css" type="text/css" media="screen" />
		<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/assets/stylesheets/others.css" type="text/css" media="screen" />
		<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />

		<?php wp_head(); ?>

		<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/assets/javascripts/min/application.js" charset="utf-8"></script>

	</head>
	
	<body <?php body_class(); ?>>
	<header>
		<div class="headerTop">
			<div class="row">
				<div class="col12">
					<nav class="headerTop-nav">
						<ul>
							<li><a target="_blank" href="https://www.facebook.com/Narcodata/"><i class="flaticon social icon icon-16 facebook-1"></i> Facebook</a></li>
							<li><a target="_blank" href="https://twitter.com/narcodata"><i class="flaticon social icon icon-16 twitter-1"></i> Twitter</a></li>
							<li><a target="_blank" href="http://www.animalpolitico.com/contactanos/"><i class="flaticon solid icon icon-16 mail-1"></i> Enviar</a></li>
							<li class="dropdown headerTop-search">
								<a href="#" class="dropdown-toggle" data-toggle="dropdown">
									<i class="flaticon stroke icon icon-32 zoom-2"></i> Search
								</a>
								<div class="dropdown-menu">
									<a href="#" class="dropdown-menu-close">
										<i class="flaticon stroke icon icon-32 x-1"></i> cerrar
									</a>
									<div class="row-table">
										<div class="row-cell middle">
											<form role="search" method="get" class="search-form" action="<?php echo home_url( '/' ); ?>">
												<label>
													<span class="screen-reader-text"><?php echo _x( 'Search for:', 'label' ) ?></span>
													<input type="search" class="search-field" placeholder="<?php echo esc_attr_x( 'Buscar …', 'placeholder' ) ?>" value="<?php echo get_search_query() ?>" name="s" title="<?php echo esc_attr_x( 'Search for:', 'label' ) ?>" />
												</label>
												<input type="submit" class="search-submit" value="Ok" />
											</form>
										</div>
									</div>
								</div>
							</li>
							<li class="dropdown headerTop-menuMobile">
								<a href="#" class="dropdown-toggle" data-toggle="dropdown">
									<i class="flaticon stroke icon icon-32 menu-2"></i> Menu
								</a>
								<div class="dropdown-menu">
									<a href="#" class="dropdown-menu-close">
										<i class="flaticon stroke icon icon-32 x-1"></i> cerrar
									</a>
									<div class="row-table">
										<div class="row-cell middle">
											<?php
												$defaults = array(
													'menu'            => 'NavMenu',
													'container'       => 'ul',
													'menu_class'      => 'dropdown-menu-list',
												);
												wp_nav_menu( $defaults );
											?>
										</div>
									</div>
								</div>
							</li>
						</ul>
					</nav>
					<h2 class="narcoData"><a href="<?php echo home_url(); ?>">NarcoData</a></h2>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col12">
				<?php
					$defaults = array(
						'menu'            => 'NavMenu',
						'container'       => 'nav',
						'container_class' => 'headerNav',
						'container_id'    => 'site-navigation',
						'menu_class'      => 'menu',
					);
					wp_nav_menu( $defaults );
				?>
			</div>
		</div>
	</header>


	<section class="wrap">