<?php /* Template Name: Reportaje */ ?>

<?php get_header(); ?>

<div class="row-module sectionArticle">

	<div class="row">
		<?php if(get_field('cabecera')) : ?>
			<div class="col12">
				<div class="headingTop">
					<span><?php the_field('cabecera'); ?></span>
				</div>
			</div>
		<?php endif; ?>
		<div class="col10 prefix1 nofloat">
			<div class="heading nomargin">
				<h1><?php the_title(); ?></h1>
				<?php
					if(get_field('subtitulo')) {
						echo '<p>' . get_field('subtitulo') . '</p>';
					}
				?>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col10 prefix1 nofloat">
			<div class="text">
				<?php if ( have_posts() ) : while( have_posts() ) : the_post(); the_content();
				endwhile; endif; ?>
			</div>
		</div>
	</div>
</div>


<div class="row-module sectionComments">
	<div class="row">
		<div class="col10 prefix1">
			<div id="disqus_thread"></div>
			<script type="text/javascript">
			    /* * * CONFIGURATION VARIABLES * * */
			    var disqus_shortname = 'ndata';
			    
			    /* * * DON'T EDIT BELOW THIS LINE * * */
			    (function() {
			        var dsq = document.createElement('script'); dsq.type = 'text/javascript'; dsq.async = true;
			        dsq.src = '//' + disqus_shortname + '.disqus.com/embed.js';
			        (document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(dsq);
			    })();
			</script>
			<noscript>Please enable JavaScript to view the <a href="https://disqus.com/?ref_noscript" rel="nofollow">comments powered by Disqus.</a></noscript>
		</div>
	</div>
</div>

<?php get_footer(); ?>